const double SHADOW_OFFSET = 8;
const double SHADOW_BLUR = 8;
