String toTitleCase(String string) {
  return '${string[0].toUpperCase()}${string.substring(1, string.length)}';
}
